from .myopenai import myopenai

# エイリアスとしてmyopenaiを直接インポート可能にする
myopenai = myopenai
